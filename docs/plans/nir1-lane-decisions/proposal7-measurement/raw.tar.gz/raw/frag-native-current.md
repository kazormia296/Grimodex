| S | seed | 結果 | call p50／最大 ms | lease p50／最大 ms | n |
|---|---|---|---|---|---|
| 10 | m1 | available nodes=10 edges=21 | 30.36／32.64 | 28.93／31.29 | 10 |
| 10 | m2 | available nodes=10 edges=21 | 32.79／37.84 | 31.43／36.47 | 10 |
| 10 | m3 | available nodes=10 edges=21 | 32.27／36.87 | 30.97／35.53 | 10 |
| 10 | m5 | available nodes=1 edges=0 | 8.03／9.64 | 6.91／8.53 | 10 |
| 10 | c01 | available nodes=7 edges=14 | 28.16／35.44 | 26.78／34.13 | 10 |
| 20 | m1 | available nodes=11 edges=40 | 57.34／58.42 | 56.30／57.73 | 10 |
| 20 | m2 | available nodes=11 edges=40 | 60.09／63.83 | 59.40／62.30 | 10 |
| 20 | m3 | available nodes=11 edges=40 | 57.15／58.04 | 56.48／57.36 | 10 |
| 20 | m5 | available nodes=2 edges=1 | 13.72／14.68 | 12.58／13.56 | 10 |
| 20 | c01 | available nodes=7 edges=28 | 53.54／54.63 | 51.98／53.06 | 10 |
| 30 | m1 | refused post-stamp-steps/-steps | 61.38／63.24 | - | 10 |
| 30 | m2 | refused post-stamp-steps/-steps | 59.39／62.49 | - | 10 |
| 30 | m3 | refused post-stamp-steps/-steps | 60.62／63.49 | - | 10 |
| 30 | m5 | available nodes=2 edges=2 | 18.87／19.11 | 17.73／17.94 | 10 |
| 30 | c01 | refused post-stamp-steps/-steps | 61.46／63.01 | - | 10 |
| 50 | m1 | refused work-revision-record-limit/-revision-record-limit | 53.49／55.31 | - | 10 |
| 50 | m2 | refused work-revision-record-limit/-revision-record-limit | 52.86／56.54 | - | 10 |
| 50 | m3 | refused work-revision-record-limit/-revision-record-limit | 55.88／56.95 | - | 10 |
| 50 | m5 | available nodes=2 edges=3 | 29.80／30.31 | 28.59／29.10 | 10 |
| 50 | c01 | refused work-revision-record-limit/-revision-record-limit | 52.34／54.58 | - | 10 |
| 80 | m1 | refused work-disclosure-record-limit/-disclosure-record-limit | 22.17／22.89 | - | 10 |
| 80 | m2 | refused work-revision-record-limit/-revision-record-limit | 28.54／29.91 | - | 10 |
| 80 | m3 | refused work-revision-record-limit/-revision-record-limit | 29.11／30.10 | - | 10 |
| 80 | m5 | refused work-disclosure-record-limit/-disclosure-record-limit | 42.23／46.52 | - | 10 |
| 80 | c01 | refused work-revision-record-limit/-revision-record-limit | 23.34／24.02 | - | 10 |
