| S | seed | 結果 | call p50／最大 ms | lease p50／最大 ms | n |
|---|---|---|---|---|---|
| 20 | m1 | available nodes=11 edges=40 | 58.47／59.82 | 57.92／58.57 | 10 |
| 20 | m2 | available nodes=11 edges=40 | 61.04／62.05 | 59.97／61.09 | 10 |
| 20 | c01 | available nodes=7 edges=28 | 53.44／54.24 | 51.83／52.68 | 10 |
| 20 | m5 | available nodes=2 edges=1 | 13.72／14.22 | 12.56／13.06 | 10 |
| 30 | m1 | available nodes=13 edges=59 | 86.80／88.13 | 85.46／87.21 | 10 |
| 30 | m2 | available nodes=13 edges=59 | 89.03／90.74 | 88.01／89.15 | 10 |
| 30 | c01 | available nodes=7 edges=39 | 76.46／78.07 | 75.74／77.37 | 10 |
| 30 | m5 | available nodes=2 edges=2 | 19.07／19.89 | 17.91／18.70 | 10 |
| 40 | m1 | available nodes=13 edges=80 | 111.84／112.98 | 110.62／111.84 | 10 |
| 40 | m2 | available nodes=13 edges=80 | 114.16／116.76 | 113.00／115.95 | 10 |
| 40 | c01 | available nodes=7 edges=53 | 100.86／102.51 | 99.15／101.63 | 10 |
| 40 | m5 | available nodes=2 edges=2 | 24.38／24.77 | 23.17／23.63 | 10 |
| 50 | m1 | available nodes=13 edges=99 | 139.78／150.33 | 138.34／149.52 | 10 |
| 50 | m2 | available nodes=13 edges=99 | 144.37／150.49 | 143.34／148.62 | 10 |
| 50 | c01 | available nodes=7 edges=67 | 125.27／127.91 | 124.48／126.90 | 10 |
| 50 | m5 | available nodes=2 edges=3 | 29.76／30.27 | 28.54／29.06 | 10 |
