| S | seed | 結果 | call p50／最大 ms | lease p50／最大 ms | n |
|---|---|---|---|---|---|
| 30 | m1 | available nodes=13 edges=59 | 84.83／85.28 | 83.41／84.31 (n=10) | 10 |
| 30 | c01 | available nodes=7 edges=39 | 75.15／75.77 | 74.50／75.06 (n=10) | 10 |
| 30 | m5 | available nodes=2 edges=2 | 18.77／19.11 | 17.62／17.94 (n=10) | 10 |
| 34 | m1 | available nodes=13 edges=68 | 95.46／96.83 | 94.39／95.75 (n=10) | 10 |
| 34 | c01 | available nodes=7 edges=47 | 87.65／88.37 | 86.86／87.71 (n=10) | 10 |
| 34 | m5 | available nodes=2 edges=2 | 18.92／19.33 | 17.77／18.21 (n=10) | 10 |
| 36 | m1 | refused NIR1_GRAPH_QUERY_DEADLINE_NO_TIMELY_FRAME | 100.87／101.95 | - | 10 |
| 36 | c01 | available nodes=7 edges=48 | 90.27／93.42 | 89.30／92.67 (n=10) | 10 |
| 36 | m5 | available nodes=2 edges=2 | 21.73／22.64 | 20.59／21.49 (n=10) | 10 |
| 38 | m1 | refused NIR1_GRAPH_QUERY_DEADLINE_NO_TIMELY_FRAME | 100.89／101.92 | - | 10 |
| 38 | c01 | available nodes=7 edges=50 | 96.60／98.66 | 95.23／96.97 (n=10) | 10 |
| 38 | m5 | available nodes=2 edges=2 | 21.90／22.42 | 20.75／21.27 (n=10) | 10 |
| 40 | m1 | refused NIR1_GRAPH_QUERY_DEADLINE_NO_TIMELY_FRAME | 100.85／101.83 | - | 10 |
| 40 | c01 | refused NIR1_GRAPH_QUERY_DEADLINE_NO_TIMELY_FRAME | 100.54／101.17 | 98.11／99.82 (n=7) | 10 |
| 40 | m5 | available nodes=2 edges=2 | 24.19／24.84 | 23.00／23.67 (n=10) | 10 |
| 50 | m1 | refused NIR1_GRAPH_QUERY_DEADLINE_NO_TIMELY_FRAME | 100.95／102.02 | - | 10 |
| 50 | c01 | refused NIR1_GRAPH_QUERY_DEADLINE_NO_TIMELY_FRAME | 100.92／100.98 | - | 10 |
| 50 | m5 | available nodes=2 edges=3 | 29.88／34.04 | 28.69／32.82 (n=10) | 10 |
